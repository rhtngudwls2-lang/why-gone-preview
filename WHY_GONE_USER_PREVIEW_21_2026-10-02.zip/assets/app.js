import {normalized,normalizeBasePath,atBase} from './core.mjs';
const BASE=normalizeBasePath(document.body.dataset.basePath||'/');
const $$=(s)=>[...document.querySelectorAll(s)];
const $=(s)=>document.querySelector(s);
let toastTimer;
function toast(message){const t=$('#toast');t.textContent=message;t.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{t.hidden=true;},3800);}
const KEY='why-gone:saved:v1';
const validIDs=new Set($$('[data-record]').map(x=>x.dataset.record).concat($$('[data-save]').map(x=>x.dataset.save)));
function getSaved(){try{const data=JSON.parse(localStorage.getItem(KEY)||'[]');return new Set(Array.isArray(data)?data.filter(x=>typeof x==='string'&&/^[a-z0-9-]+$/.test(x)).slice(0,1000):[]);}catch{return new Set();}}
let saved=getSaved();
function store(next){try{localStorage.setItem(KEY,JSON.stringify([...next]));saved=next;return true;}catch{toast('이 브라우저에서 저장할 수 없습니다. 저장 공간·브라우저 설정을 확인해 주세요.');return false;}}
function paintSaved(){
 $$('[data-save]').forEach(b=>{const yes=saved.has(b.dataset.save);b.setAttribute('aria-pressed',String(yes));const label=b.querySelector('[data-save-label]');if(label)label.textContent=yes?'저장됨 · 다시 누르면 해제':'이 브라우저에 저장';else b.setAttribute('aria-label',`${b.dataset.save} ${yes?'저장 해제':'저장'}`);});
 if(document.body.dataset.page==='saved'){
  let count=0;$$('#saved-grid [data-record]').forEach(c=>{c.hidden=!saved.has(c.dataset.record);if(!c.hidden)count++;});
  $('#saved-count').textContent=`${count}개 저장됨`;$('#saved-empty').hidden=count!==0;$('#clear-saved').disabled=!saved.size;
 }
}
$$('[data-save]').forEach(b=>b.addEventListener('click',()=>{const next=new Set(saved),id=b.dataset.save;if(next.has(id))next.delete(id);else next.add(id);if(store(next)){paintSaved();toast(next.has(id)?'이 브라우저에 저장했습니다.':'저장을 해제했습니다.');}}));
$('#clear-saved')?.addEventListener('click',()=>{if(!window.confirm('이 브라우저에 저장한 기록을 모두 지울까요?'))return;if(store(new Set())){paintSaved();toast('저장 목록을 지웠습니다.');}});
window.addEventListener('storage',ev=>{if(ev.key===KEY){saved=getSaved();paintSaved();}});
paintSaved();
$$('[data-share]').forEach(b=>b.addEventListener('click',async()=>{
 const url=location.href.split('#')[0];
 try{if(navigator.share){await navigator.share({title:document.title,url});return;}if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(url);toast('기록 주소를 복사했습니다.');return;}}catch(err){if(err.name==='AbortError')return;}
 const dialog=$('#share-dialog');$('#share-url').value=url;dialog.showModal();$('#share-url').select();
}));
$$('[data-random]').forEach(b=>b.addEventListener('click',()=>{const ids=(document.body.dataset.recordIds||'').split(',').filter(id=>/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id));if(!ids.length)return;const r=crypto.getRandomValues(new Uint32Array(1))[0];location.assign(atBase(BASE,`/record/${ids[r%ids.length]}/`));}));
if(document.body.dataset.page==='explore'){
 const input=$('#query'),status=$('#status-filter'),year=$('#year-filter'),radios=$$('input[name="category"]'),cards=$$('#search-results [data-record]');
 function stateFromURL(){const p=new URLSearchParams(location.search);input.value=(p.get('q')||'').slice(0,120);status.value=[...status.options].some(o=>o.value===p.get('status'))?p.get('status'):'all';year.value=[...year.options].some(o=>o.value===p.get('year'))?p.get('year'):'all';let cat=p.get('category')||'all';if(!radios.some(r=>r.value===cat))cat='all';radios.forEach(r=>{r.checked=r.value===cat;});}
 function apply(updateURL=true){const q=input.value.trim(),words=q.split(/\s+/).filter(Boolean).map(normalized),cat=radios.find(r=>r.checked)?.value||'all';let count=0;
  cards.forEach(c=>{const show=words.every(w=>c.dataset.search.includes(w))&&(cat==='all'||c.dataset.category===cat)&&(status.value==='all'||c.dataset.status===status.value)&&(year.value==='all'||c.dataset.year===year.value);c.hidden=!show;if(show)count++;});
  $('#result-count').textContent=q?`‘${q}’ 검색 결과 ${count}개`:`${count}개 기록`;$('#empty-state').hidden=count>0;
  if(updateURL){const p=new URLSearchParams();if(q)p.set('q',q);if(cat!=='all')p.set('category',cat);if(status.value!=='all')p.set('status',status.value);if(year.value!=='all')p.set('year',year.value);history.replaceState(null,'',atBase(BASE,`/explore/${p.size?'?'+p:''}`));}
 }
 stateFromURL();apply(false);
 $('.search-form').addEventListener('submit',ev=>{ev.preventDefault();apply();});
 input.addEventListener('input',()=>apply());[status,year,...radios].forEach(el=>el.addEventListener('change',()=>apply()));
 $('#reset-filters').addEventListener('click',()=>{input.value='';status.value='all';year.value='all';radios.forEach(r=>{r.checked=r.value==='all';});apply();input.focus();});
 window.addEventListener('popstate',()=>{stateFromURL();apply(false);});
}
