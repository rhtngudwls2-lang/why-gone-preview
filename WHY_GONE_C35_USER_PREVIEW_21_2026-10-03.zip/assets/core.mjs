// Only the three helpers used by the published browser script belong in dist/.
// The complete source validator and editorial rules remain in the private source tree.
export function normalized(v=''){return String(v).normalize('NFKC').toLocaleLowerCase('ko').replace(/\s+/g,'');}
export function normalizeBasePath(value='/'){
 if(typeof value!=='string'||value.length>200||!/^\/(?:[A-Za-z0-9_-]+\/)*[A-Za-z0-9_-]*$/.test(value))throw Error('Invalid base path');
 return value.endsWith('/')?value:value+'/';
}
export function atBase(base,value){
 base=normalizeBasePath(base);
 if(typeof value!=='string'||!/^\/(?!\/)/.test(value)||/[\\\x00-\x20]/.test(value)||value.split(/[?#]/)[0].split('/').some(x=>x==='.'||x==='..'))throw Error('Invalid site path');
 return base+value.slice(1);
}
