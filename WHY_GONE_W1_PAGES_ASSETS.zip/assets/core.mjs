// Public search helper. Editorial validation stays in the private source tree.
export function normalized(v=''){return String(v).normalize('NFKC').toLocaleLowerCase('ko').replace(/\s+/g,'');}
