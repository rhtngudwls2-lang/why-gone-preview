const toc=document.querySelector('.toc');
if(toc){
 const links=[...toc.querySelectorAll('a')];
 const sections=links.map(link=>document.getElementById(link.hash.slice(1))).filter(Boolean);
 let navigationTarget=sections.find(section=>'#'+section.id===location.hash)?.id||null;
 let framePending=false;
 const mark=id=>{for(const link of links){if(link.hash==='#'+id)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');}};
 const update=()=>{
  framePending=false;
  if(navigationTarget){mark(navigationTarget);return;}
  const line=(document.querySelector('header')?.getBoundingClientRect().bottom||0)+24;
  const section=sections.find(section=>section.getBoundingClientRect().bottom>line)||sections.at(-1);
  if(section)mark(section.id);
 };
 const schedule=()=>{if(!framePending){framePending=true;requestAnimationFrame(update);}};
 const manualMove=()=>{navigationTarget=null;schedule();};
 toc.addEventListener('click',event=>{const link=event.target.closest('a');if(links.includes(link)){navigationTarget=link.hash.slice(1);mark(navigationTarget);}});
 window.addEventListener('scroll',schedule,{passive:true});
 window.addEventListener('wheel',manualMove,{passive:true});
 window.addEventListener('touchstart',manualMove,{passive:true});
 window.addEventListener('pointerdown',event=>{if(!toc.contains(event.target))manualMove();},{passive:true});
 window.addEventListener('keydown',event=>{if(['ArrowDown','ArrowUp','PageDown','PageUp','Home','End',' '].includes(event.key))manualMove();});
 window.addEventListener('resize',manualMove);
 window.addEventListener('hashchange',()=>{const target=sections.find(section=>'#'+section.id===location.hash);if(target){navigationTarget=target.id;mark(target.id);}});
 update();
}

// Native details allow multiple years open; year links open their own group.
document.querySelectorAll('.year-nav a').forEach(link=>link.addEventListener('click',()=>{document.getElementById(link.hash.slice(1))?.closest('details')?.setAttribute('open','');}));
